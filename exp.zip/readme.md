### development

    npm run servenpm 
    npm run dev-server

### to start tests running

    npm test -- --watchAll
    
### build for production

    npm run build:prod